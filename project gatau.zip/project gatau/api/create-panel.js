function generatePassword(username) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let suffix = "";
  for (let i = 0; i < 4; i++) {
    suffix += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return username + suffix;
}

const planMap = {
  "1GB": { memory: 1024, disk: 10240, cpu: 50 },
  "2GB": { memory: 2048, disk: 20480, cpu: 100 },
  "3GB": { memory: 3072, disk: 30720, cpu: 150 },
  "4GB": { memory: 4096, disk: 40960, cpu: 200 },
  "5GB": { memory: 5120, disk: 51200, cpu: 250 },
  "6GB": { memory: 6144, disk: 61440, cpu: 300 },
  "7GB": { memory: 7168, disk: 71680, cpu: 350 },
  "8GB": { memory: 8192, disk: 81920, cpu: 400 },
  "9GB": { memory: 9216, disk: 92160, cpu: 450 },
  "10GB": { memory: 10240, disk: 102400, cpu: 500 },
  "UNLIMITED": { memory: 0, disk: 0, cpu: 0 }
};

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ message: "Method not allowed" });

  const { username, plan, isAdmin } = req.body;
  if (!username || !plan) return res.status(400).json({ message: "Username dan plan wajib diisi" });

  const API_URL = "https://milokanjayy.anti-ddos.me/api/application";
  const API_KEY = "ptlc_eph7HwfIk076EDWiP9VgIeQxOEgi1w8GWaNrfIEJJjs";
  const password = generatePassword(username);
  const limits = planMap[plan.toUpperCase()] || planMap["1GB"];

  try {
    const userRes = await fetch(`${API_URL}/users`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        username,
        email: `${username}@example.com`,
        password,
        root_admin: isAdmin === true
      }),
    });

    const userData = await userRes.json();
    const userId = userData.attributes.id;

    const serverRes = await fetch(`${API_URL}/servers`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        name: username,
        user: userId,
        egg: 999,
        nest: 999,
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: "${CMD_RUN}",
        environment: {
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          CMD_RUN: "npm install"
        },
        limits,
        feature_limits: {}
      }),
    });

    const serverData = await serverRes.json();
    res.status(200).json({
      username,
      password,
      panel_host: API_URL.replace("/api/application", ""),
      server_id: serverData.attributes.id,
      plan,
      ram: limits.memory === 0 ? "Unlimited" : limits.memory + " MB",
      disk: limits.disk === 0 ? "Unlimited" : (limits.disk / 1024) + " GB",
      cpu: limits.cpu === 0 ? "Unlimited" : limits.cpu + " %",
      isAdmin
    });
  } catch (e) {
    res.status(500).json({ message: e.message || "Server error" });
  }
}