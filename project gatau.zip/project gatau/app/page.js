"use client";
import { useState } from "react";

export default function Page() {
  const [username, setUsername] = useState("");
  const [plan, setPlan] = useState("1GB");
  const [accountType, setAccountType] = useState("user");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const plans = [
    "1GB", "2GB", "3GB", "4GB", "5GB", "6GB", "7GB", "8GB", "9GB", "10GB", "Unlimited"
  ];

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    setError(null);

    try {
      const res = await fetch("/api/create-panel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, plan, isAdmin: accountType === "admin" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Gagal membuat panel");
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 400, margin: "auto", padding: 20 }}>
      <h2>Create WhatsApp Bot Panel</h2>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 15 }}>
        <label>
          Username:
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </label>
        <label>
          Plan:
          <select value={plan} onChange={(e) => setPlan(e.target.value)}>
            {plans.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </label>
        <label>
          Tipe Akun:
          <select value={accountType} onChange={(e) => setAccountType(e.target.value)}>
            <option value="user">User Biasa</option>
            <option value="admin">Admin</option>
          </select>
        </label>
        <button type="submit" disabled={loading}>
          {loading ? "Membuat Panel..." : "Buat Panel"}
        </button>
      </form>
      {error && <p style={{ color: "red" }}>❌ {error}</p>}
      {result && (
        <div style={{ marginTop: 20, padding: 15, background: "#e7fbe7", border: "1px solid green" }}>
          <h3>✔️ Panel Created Successfully!</h3>
          <p>🧠 Username: <b>{result.username}</b></p>
          <p>🔒 Password: <b>{result.password}</b></p>
          <p>📡 Panel: <a href={result.panel_host} target="_blank">{result.panel_host}</a></p>
          <p>🆔 Server ID: {result.server_id}</p>
          <p>⚙️ RAM: {result.ram}, Disk: {result.disk}, CPU: {result.cpu}</p>
          <p>👑 Akun: {result.isAdmin ? "Admin" : "User"}</p>
        </div>
      )}
    </div>
  );
}